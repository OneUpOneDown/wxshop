angular.module('starter.services', [])
//主页banner  http://127.0.0.1:8080/ly-Store/ly/banner/bannerInfo.action 
.constant("baseUrl","http://192.168.31.140:8080/ly-Store/ly/")
// http://192.168.31.140:8080/ly-Store/ly/banner/bannerInfo.action
.factory("homeServices",function($http,$q,baseUrl){
    function textljz(){
        return ljzh = "ljzqwer";
    }
    return {
        // //示例
        // getGameData: function(gameId) {
        //         var deferred = $q.defer();
        //         var url = "http://m?id="+gameId;
        //         url+="&callback=JSON_CALLBACK";
        //         $http.jsonp(url).success(function (data) {
        //           //业务处理
        //           deferred.resolve(data.data);
        //         }).error(function (error) {
        //           //业务处理
        //           deferred.reject(error)
        //         })
        //         return deferred.promise;
        //       }
        //     };
        //首页 大图
        getbanner:function(){
            var deferred = $q.defer();
            var url = baseUrl + "banner/bannerInfo.action";
            url += "?callback=JSON_CALLBACK";
            $http.jsonp(url).success(function (data){
                var data = data;
                console.log("databanner",data);
                deferred.resolve(data);
            }).error(function (error){
                console.log("error",error);
                deferred.reject(error);
            })
            return deferred.promise;
        },
        //首页产品
        getGoodslistAll:function(){
            var deferred = $q.defer();
            var url = baseUrl + "item/storeItemList.action?condition.vmCode=&condition.label=2&condition.typeId=";
            url += "&callback=JSON_CALLBACK";
            $http.jsonp(url).success(function (data){
                var data = data;
                console.log("goodslistAll",data);
                deferred.resolve(data);
            }).error(function (error){
                deferred.reject(error);
            })
            return deferred.promise;
        }

    }
})
.factory('goodsServices', function($http) {
// Might use a resource here that returns a JSON array

// Some fake testing data
var goodsRequest = function(){
    return $http.get('./data/recommend.json')
}

return {
   events: function(){
        return goodsRequest();
   }
};
})
.factory('machineServices',function($http,$q,baseUrl){
    // http 跨域问题
    return {
        getmachinelistall:function(){
            console.log("limian")
            var deferred = $q.defer();
            var url = baseUrl + "store/vending/findName.action?condition.name=加速器&condition.lon=115.478284&condition.lat=24.119538";
            url += "&callback=JSON_CALLBACK";
            $http.jsonp(url).success(function (data){
                //业务处理
                var data=data;
                console.log("data",data);
                deferred.resolve(data);
            }).error(function (error){
                //业务处理
                console.log("cuowu")
                deferred.reject(error);
            })
            return deferred.promise;
        }
    }
})
.factory("joincartServices",function($http,$q,baseUrl){
    return {
        joincartbase: function (){
            var deferred = $q.defer();
            var url = baseUrl + "shopping/alterShopping.action?condition.vmCode=&condition.id=&condition.operate=1&condition.userId=&condition.num=";
            url += "&callback=JSON_CALLBACK";
            $http.jsonp(url).success(function (data){
                var data = data;
                deferred.resolve(data);
            }).error(function (error){
                console.log(error);
                deferred.reject(error);
            })
            return deferred.promise;
        }
    }
})
.factory("ShopingcartServices",function($http,$q,baseUrl){
    return {
        getallorders: function (){
            var deferred = $q.defer();
            var url = baseUrl + "shopping/shoppingList.action?condition.vmCode=&condition.userId=";
            url += "&callback=JSON_CALLBACK";
            $http.jsonp(url).success(function (data){
                var data = data;
                deferred.resolve(data);
            }).error(function (error){
                console.log(error);
                deferred.reject(error);
            })
            return deferred.promise;
        },
        deleteorders: function (){
            var deferred = $q.defer();
            var url = baseUrl + "shopping/alterShopping.action?condition.vmCode=&condition.shoppngId=&condition.operate=2condition.userId=&condition.num="
            url += "&callback=JSON_CALLBACK";
            $http.jsonp(url).success(function (data){
                var data = data;
                deferred.resolve(data);
            }).error(function (error){
                console.log(error);
                deferred.reject(error);
            })
            return deferred.promise;
        }
    }
})
.factory("userService",function($http,$q){
    return {
        getuserinfo:function(){
            var deferred = $q.defer();
            var url = "http://sp.lianyerobot.com/index.php?s=/Home/Weixin/getuserinfo";
            $http.jsonp(url).success(function (data){
                var data = data;
                deferred.resolve(data);
            }).error(function (error){
                console.log(error);
                deferred.reject(error);
            })
            return deferred.promise;
        }
    }
})